package packt.jee.eclipse.spring;

public interface ICourseDAO {

}
