package packt.book.jeeeclipse.springboot.coursemanagementspring;

import org.springframework.data.repository.CrudRepository;

public interface CourseRepository extends CrudRepository<Course, Long>{

}
