package packt.book.jeeeclipse.springboot.coursemanagementspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursemanagementspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursemanagementspringApplication.class, args);
	}
}
